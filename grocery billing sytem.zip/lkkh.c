#include "grocery.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void displayMenu(struct GroceryItem items[], int size) {
    printf("Menu:\n");
    for (int i = 0; i < size; ++i) {
        printf("%d. %s - $%.2f\n", i + 1, items[i].name, items[i].price);
    }
}

void getCustomerDetails(char **name, char **email, char **address) {
    *name = (char *)malloc(50 * sizeof(char));
    *email = (char *)malloc(100 * sizeof(char));
    *address = (char *)malloc(100 * sizeof(char));

    printf("\nEnter your name: ");
    scanf("%s", *name);
    printf("Enter your email: ");
    scanf("%s", *email);
    printf("Enter your address: ");
    scanf("%s", *address);
}

int login(char *username, char *password) {
    if (strcmp(username, "admin") == 0 && strcmp(password, "password") == 0) {
        return 1; 
    } else {
        return 0; 
    }
}