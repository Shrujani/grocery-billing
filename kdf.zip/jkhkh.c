#ifndef GROCERY_H
#define GROCERY_H

struct GroceryItem {
    char name[50];
    float price;
};

void displayMenu(struct GroceryItem items[], int size);
void getCustomerDetails(char **name, char **email, char **address);
int login(char *username, char *password);

#endif 